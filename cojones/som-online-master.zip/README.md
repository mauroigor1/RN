# som-online
A minimalistic implementation of Self Organizing Map in python for blog.
[Unsupervised Learning with Self Organizing Maps (SOM)](https://machinelearningnepal.com/2018/01/17/online-som)
